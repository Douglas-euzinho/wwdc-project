//
//  File.swift
//  
//
//  Created by Douglas Figueirôa on 23/04/22.
//
import AVFoundation
import AVKit

/// This class aims to initialize a audio to play in the application.
public class GameAudio{
    private init(){ }
    
    static func initializateSound(soundName: String, soundType: String) -> AVAudioPlayer {
        guard let sound = Bundle.main.path(forResource: soundName, ofType: soundType) else {
            return AVAudioPlayer()
        }
        guard let audio = try? AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound)) else {
            return AVAudioPlayer()
        }
        return audio
    }
}


