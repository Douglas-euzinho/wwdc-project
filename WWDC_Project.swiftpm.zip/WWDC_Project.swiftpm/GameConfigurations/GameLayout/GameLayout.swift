//
//  File.swift
//  
//
//  Created by Douglas Figueirôa on 23/04/22.
//
import UIKit
import AVFoundation

/// This extension aims to share all common functions for any class that is of type UIViewController
extension UIViewController {
    
    /// This function aims to create a UILabel by receiving parameters from: text content, text size, text position, number of text lines. Fixed values are also created for the UILabel: font, alignment, color and constraints
    /// - Parameters:
    ///   - textContent: The message is received, the text to be displayed, being it a String
    ///   - textSize: A text size is received, which is a CGFloat
    ///   - textYPosition: A Y position is received for the text, which is a CGFloat
    ///   - numberOfLines: A number of lines are received for the text, being it an Int
    /// - Returns: Returns a UILabel
    func addTextOnScreen(textContent: String, textSize: CGFloat, textYPosition: CGFloat, numberOfLines: Int) -> UILabel {
        guard let fontName = UIFont(name: "ArialRoundedMTBold", size: UIFont.labelFontSize) else {
            return UILabel()
        }
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.font = UIFontMetrics.default.scaledFont(for: fontName)
        label.font = label.font.withSize(textSize)
        label.numberOfLines = numberOfLines
        label.text = textContent
        label.textColor = .black
        self.view.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.centerXAnchor),
            label.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor, constant: 20+textYPosition),
            label.widthAnchor.constraint(equalToConstant: 560)
        ])
        return label
    }
    
    /// This function aims to create a UIImageView by receiving parameters from: image name, image width, image height, image X position, image Y position.
    /// - Parameters:
    ///   - imageName: An asset name is received, being it a String
    ///   - imageWidth: A width is received for the image, which is a CGFloat
    ///   - imageHeight: A height is received for the image, which is a CGFloat
    ///   - imageXPosition: An Xposition is received for the image, which is a CGFloat
    ///   - imageYPosition: An Y position is received for the image, which is a CGFloat
    /// - Returns: Returns a UIImageView
    func addImageOnScreen(imageName: String, imageWidth: CGFloat, imageHeight: CGFloat, imageXPosition: CGFloat, imageYPosition: CGFloat) -> UIImageView {
        let image = UIImageView(image: UIImage(named: imageName))
        image.translatesAutoresizingMaskIntoConstraints = false
        image.frame.size.width = imageWidth
        image.frame.size.width = imageHeight
        self.view.addSubview(image)
        NSLayoutConstraint.activate([
            image.centerXAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.centerXAnchor, constant: imageXPosition),
            image.centerYAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.centerYAnchor, constant: imageYPosition)
        ])
        return image
    }
    
    /// This function aims to create a UIButton by receiving parameters from: image name. Fixed constraints are also created for the UIButton.
    /// - Parameter buttonName: An asset name is received, being it a String
    /// - Returns: Returns a UIButton
    func addButton(buttonName: String) -> UIButton {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        let buttonAssetName = UIImage(named: buttonName)
        button.setBackgroundImage(buttonAssetName, for: .normal)
        self.view.addSubview(button)
        NSLayoutConstraint.activate([
            button.centerXAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.centerXAnchor),
            button.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor, constant: -30)
        ])
        return button
    }
    
    /// This function is intended to start the music
    func playSound(){
        SoundConstants.backgroundPlayer = GameAudio.initializateSound(soundName: SoundConstants.backgroundSound, soundType: SoundConstants.soundType)
        SoundConstants.backgroundPlayer.play()
        SoundConstants.backgroundPlayer.numberOfLoops = -1
        SoundConstants.backgroundPlayer.volume = 0.42
    }
}
