//
//  File.swift
//  
//
//  Created by Douglas Figueirôa on 23/04/22.
//
import UIKit

/// Protocol that has common functions for every class that is a UIViewController
protocol CommomFunctions {
    /// Its objective is to receive an Int that indicates what should be shown on the screen according to what is implemented in the logic
    /// - Parameter level: A value is received to indicate what to show within the implemented logic, which is an Int.
    func updatePage(level: Int)
    
    /// Its purpose is to update the elements on the screen
    func updateControlPage()
    
    /// Aims to instantiate a new ViewController
    func changeToNextPage()
}

/// Protocol that has common functions for every class that is a UIViewController and that has the need to draw on the screen
protocol DrawFunctions{
    /// It aims to show the canvas view to draw on the screen
    func goToDrawPage()
    
    /// Aims to return to the view controller, leaving the canvas view
    func backToLevel()
}
