//
//  File.swift
//  
//
//  Created by Douglas Figueirôa on 23/04/22.
//
import UIKit
import AVFoundation

/// Structure that stores constant color variables
struct ColorConstants {
    static let allBackgroundColor = UIColor(hex: "#E0F1F6FF")
}

/// Structure that stores exercise variables for each specific level to be used anywhere in a simple way.
struct ExercicesConstants {
    static let listExercicesLevel1 = [1: AssetsConstants.dashesExercice, 2: AssetsConstants.circlesExercice]
    static let listExercicesLevel2 = [1: AssetsConstants.cExercice, 2: AssetsConstants.sExercice]
    static let listExercicesLevel3 = [1: AssetsConstants.vanishingPointExercice]
}

/// Structure that stores asset variables (buttons, exercises, examples, characters and progress) to be used anywhere in a simple way.
struct AssetsConstants {
    static let playButton = "PlayButton"
    static let nextButton = "NextButton"
    static let finishedButton = "FinishedButton"
    
    static let dashesExercice = "DashesExercice"
    static let circlesExercice = "CirclesExercice"
    static let cExercice = "cExercice"
    static let sExercice = "sExercice"
    static let vanishingPointExercice = "VanishingPointExercice"
    
    static let cExerciceExample = "cExerciceExample"
    static let sExerciceExample = "sExerciceExample"
    static let vpExerciceExample = "vpExerciceExample"
    
    static let bobInitialLevel0 = "BobInitialLevel0"
    static let bobTalkLevel0 = "BobTalkLevel0"
    static let bobInitialLevel1 = "BobInitialLevel1"
    static let bobTalkLevel1 = "BobTalkLevel1"
    static let bobInitialLevel2 = "BobInitialLevel2"
    static let bobTalkLevel2 = "BobTalkLevel2"
    
    static let progress1 = "Progress1"
    static let progress2 = "Progress2"
    static let progress3 = "Progress3"
    static let progress4 = "Progress4"
}

/// Structure that stores level 0 text variables for simple use.
struct TextLevel0Constants {
    static let text1 = "Understanding"
    static let text2 = "Design Basics with,"
    static let text3 = "Bob"
    static let text4 = "Hello, i'm Bob!"
    static let text5 = "Today we will learn about design basics!"
    static let text6 = "You will understand basic concepts and techniques ways to draw!"
    static let text7 = "I hope you learn more than my creator :D"
}

/// Structure that stores level 1 text variables for simple use.
struct TextLevel1Constants {
    static let text1 = "Chapter One:"
    static let text2 = "Circles and Dashes!"
    static let text3 = "Let's start drawing trace! Draw over each gray stroke, to train your firmness in your hand."
    static let text4 = "Well Done!"
    static let text5 = "Keep practing to level up!"
    static let text6 = "Now let's draw circles! Draw over each gray circle, it is also a training to create firmness in your hand!"
    static let text7 = "You got it!"
    static let text8 = "You leveled up!"
    static let text9 = "With each chapter completed, my drawing will become more and more elaborate! Keep evolving!"
}

/// Structure that stores level 2 text variables for simple use.
struct TextLevel2Constants {
    static let text1 = "Chapter Two:"
    static let text2 = "Curves!"
    static let text3 = "Let's make some curves! Draw passing through THREE dots to form the letter ”C”! See an example of how to do it!"
    static let text4 = "Well Done!"
    static let text5 = "Keep practing to level up!"
    static let text6 = "Now draw through FOUR dots to form the letter 'S'. See an example of how to do it!"
    static let text7 = "You got it!"
    static let text8 = "You leveled up!"
    static let text9 = "You just learned to be more skillful when making turns. It is important to have more control when drawing curves. Keep practicing!"
}

/// Structure that stores level 3 text variables for simple use.
struct TextLevel3Constants {
    static let text1 = "Chapter Three:"
    static let text2 = "Vanishing Point!"
    static let text3 = "Draw an object passing through the gray points and then for each point used, draw a straight line to the vanishing point(painted in black)! See an example of how to do it!"
    static let text4 = "You Finished!"
    static let text5 = "You've learned to master the vanishing point. Now you get the sense of depth and keep the perspective that an observer would have from a given point of view."
    static let text6 = "I hope you learned a lot from each activity! Keep practicing to improve your skills, don't forget about our activities, I'm sure you're better than when you started!"
}

/// Structure that stores sounds variables for use.
struct SoundConstants {
    static var backgroundPlayer = AVAudioPlayer()
    static let backgroundSound = "BackgroundSound"
    static let soundType = ".wav"
}
