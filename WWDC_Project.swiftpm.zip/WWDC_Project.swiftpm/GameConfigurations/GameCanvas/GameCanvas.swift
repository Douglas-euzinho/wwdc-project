//
//  File.swift
//  
//
//  Created by Douglas Figueirôa on 23/04/22.
//
import UIKit

/// This class aims to create a view for drawing, in which, according to the user's touch, a line is created until the end of the touch.
class Canvas: UIView {
    var canvasLines = [[CGPoint]]()
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)
        guard let context = UIGraphicsGetCurrentContext() else { return }
        context.setStrokeColor(UIColor.black.cgColor)
        context.setLineWidth(14)
        context.setLineCap(.butt)
        canvasLines.forEach { (canvasLine) in
            for (x,y) in canvasLine.enumerated() {
                if x==0 {
                    context.move(to: y)
                } else {
                    context.addLine(to: y)
                }
            }
        }
        context.strokePath()
    }

    public func removeLines() {
        canvasLines.removeAll()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        canvasLines.append([CGPoint]())
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touchPoint = touches.first?.location(in: nil) else { return }
        guard var lastCanvasLine = canvasLines.popLast() else { return }
        lastCanvasLine.append(touchPoint)
        canvasLines.append(lastCanvasLine)
        setNeedsDisplay()
    }
}
