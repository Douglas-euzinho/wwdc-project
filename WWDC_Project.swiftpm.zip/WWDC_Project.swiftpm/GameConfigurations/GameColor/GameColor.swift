//
//  File.swift
//  
//
//  Created by Douglas Figueirôa on 23/04/22.
//
import UIKit

/// This UIColor extension allows RGB colors to be placed according to a hexadecimal parameter received.
extension UIColor {
    public convenience init!(hex: String) {
        let red, green, blue, alpha: CGFloat

        if hex.hasPrefix("#") {
            let firstIndex = hex.index(hex.startIndex, offsetBy: 1)
            let color = String(hex[firstIndex...])
            if color.count == 8 {
                let scanner = Scanner(string: color)
                var hexNumber: UInt64 = 0
                if scanner.scanHexInt64(&hexNumber) {
                    red = CGFloat((hexNumber & 0xff000000) >> 24) / 255
                    green = CGFloat((hexNumber & 0x00ff0000) >> 16) / 255
                    blue = CGFloat((hexNumber & 0x0000ff00) >> 8) / 255
                    alpha = CGFloat(hexNumber & 0x000000ff) / 255
                    self.init(red: red, green: green, blue: blue, alpha: alpha)
                    return
                }
            }
        }
        return nil
    }
}
