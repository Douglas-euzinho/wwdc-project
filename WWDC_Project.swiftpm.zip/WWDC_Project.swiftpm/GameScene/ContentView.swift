import SwiftUI

struct ContentView: View {
    var body: some View {
        uiViewCall()
    }
}

/// A representation of the UIKit is created to be displayed inside the SwiftUI
struct uiViewCall: UIViewControllerRepresentable {
    typealias UIViewControllerType = Level0

    func makeUIViewController(context: Context) -> Level0 {
        let view = Level0()
        view.modalPresentationStyle = .fullScreen
        return view
    }
    
    func updateUIViewController(_ uiViewController: Level0, context: Context) {
    }
}
