//
//  File.swift
//  
//
//  Created by Douglas Figueirôa on 23/04/22.
//
import UIKit
import AVFoundation
import AVKit

/// Class representing the introductory level of the application
public class Level0: UIViewController, CommomFunctions {
    lazy var canvas = Canvas()
    lazy var buttonView = UIButton()
    lazy var imageArray = [UIImageView]()
    lazy var labelArray = [UILabel]()
    private var update: Int = 0
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = ColorConstants.allBackgroundColor!
        self.updatePage(level: update)
        playSound()
    }
    
    func updatePage(level: Int) {
        switch level {
        case 0:
            let label1 = addTextOnScreen(textContent: TextLevel0Constants.text1, textSize: 38, textYPosition: 0, numberOfLines: 1)
            let label2 = addTextOnScreen(textContent: TextLevel0Constants.text2, textSize: 48, textYPosition: 60, numberOfLines: 1)
            let label3 = addTextOnScreen(textContent: TextLevel0Constants.text3, textSize: 58, textYPosition: 140, numberOfLines: 1)
            labelArray.append(contentsOf: [label1, label2, label3])
            let image1 = addImageOnScreen(imageName: AssetsConstants.bobInitialLevel0, imageWidth: 130, imageHeight: 100, imageXPosition: 0, imageYPosition: 0)
            imageArray.append(image1)
            buttonView = addButton(buttonName: AssetsConstants.playButton)
            buttonView.addTarget(self, action: #selector(updateControlPage), for: .touchUpInside)
            break
        case 1:
            let label1 = addTextOnScreen(textContent: TextLevel0Constants.text4, textSize: 28, textYPosition: 100, numberOfLines: 1)
            labelArray.append(contentsOf: [label1])
            let image1 = addImageOnScreen(imageName: AssetsConstants.bobTalkLevel0, imageWidth: 130, imageHeight: 101, imageXPosition: 0, imageYPosition: 0)
            imageArray.append(image1)
            buttonView = addButton(buttonName: AssetsConstants.nextButton)
            buttonView.addTarget(self, action: #selector(updateControlPage), for: .touchUpInside)
            break
        case 2:
            let label1 = addTextOnScreen(textContent: TextLevel0Constants.text5, textSize: 28, textYPosition: 100, numberOfLines: 2)
            labelArray.append(contentsOf: [label1])
            let image1 = addImageOnScreen(imageName: AssetsConstants.bobTalkLevel0, imageWidth: 130, imageHeight: 101, imageXPosition: 0, imageYPosition: 0)
            imageArray.append(image1)
            buttonView = addButton(buttonName: AssetsConstants.nextButton)
            buttonView.addTarget(self, action: #selector(updateControlPage), for: .touchUpInside)
            break
        case 3:
            let label1 = addTextOnScreen(textContent: TextLevel0Constants.text6, textSize: 28, textYPosition: 100, numberOfLines: 3)
            labelArray.append(contentsOf: [label1])
            let image1 = addImageOnScreen(imageName: AssetsConstants.bobTalkLevel0, imageWidth: 130, imageHeight: 101, imageXPosition: 0, imageYPosition: 0)
            imageArray.append(image1)
            buttonView = addButton(buttonName: AssetsConstants.nextButton)
            buttonView.addTarget(self, action: #selector(updateControlPage), for: .touchUpInside)
            break
        case 4:
            let label1 = addTextOnScreen(textContent: TextLevel0Constants.text7, textSize: 28, textYPosition: 100, numberOfLines: 2)
            labelArray.append(contentsOf: [label1])
            let image1 = addImageOnScreen(imageName: AssetsConstants.bobTalkLevel0, imageWidth: 130, imageHeight: 101, imageXPosition: 0, imageYPosition: 0)
            imageArray.append(image1)
            buttonView = addButton(buttonName: AssetsConstants.nextButton)
            buttonView.addTarget(self, action: #selector(updateControlPage), for: .touchUpInside)
            break
        default:
            changeToNextPage()
            break
        }
    }
    
    @objc func updateControlPage() {
        self.update += 1
        labelArray.forEach { label in
            label.removeFromSuperview()
        }
        labelArray.removeAll()
        imageArray.forEach { image in
            image.removeFromSuperview()
        }
        imageArray.removeAll()
        buttonView.removeFromSuperview()
        labelArray = [UILabel]()
        imageArray = [UIImageView]()
        buttonView = UIButton()
        updatePage(level: update)
    }
    
    func changeToNextPage() {
        let level = Level1()
        level.modalPresentationStyle = .fullScreen
        self.present(level, animated: false)
    }
}
