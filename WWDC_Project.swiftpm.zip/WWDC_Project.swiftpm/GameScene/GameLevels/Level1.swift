//
//  File.swift
//  
//
//  Created by Douglas Figueirôa on 23/04/22.
//
import UIKit

/// Class representing the first level of the application
public class Level1: UIViewController, CommomFunctions, DrawFunctions {
    lazy var canvas = Canvas()
    lazy var buttonView = UIButton()
    lazy var imageArray = [UIImageView]()
    lazy var labelArray = [UILabel]()
    private var nextListExercice: Int = 1
    private var isInExercice: Bool = false
    private var update: Int = 0
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = ColorConstants.allBackgroundColor!
        self.updatePage(level: update)
    }

    func updatePage(level: Int) {
        switch level {
        case 0:
            let label1 = addTextOnScreen(textContent: TextLevel1Constants.text1, textSize: 38, textYPosition: 0, numberOfLines: 1)
            let label2 = addTextOnScreen(textContent: TextLevel1Constants.text2, textSize: 48, textYPosition: 90, numberOfLines: 1)
            labelArray.append(contentsOf: [label1, label2])
            let image1 = addImageOnScreen(imageName: AssetsConstants.bobInitialLevel0, imageWidth: 130, imageHeight: 100, imageXPosition: 0, imageYPosition: 0)
            imageArray.append(image1)
            buttonView = addButton(buttonName: AssetsConstants.playButton)
            buttonView.addTarget(self, action: #selector(updateControlPage), for: .touchUpInside)
            break
        case 1:
            let label1 = addTextOnScreen(textContent: TextLevel1Constants.text3, textSize: 28, textYPosition: 100, numberOfLines: 3)
            labelArray.append(contentsOf: [label1])
            let image1 = addImageOnScreen(imageName: AssetsConstants.bobTalkLevel0, imageWidth: 130, imageHeight: 100, imageXPosition: 0, imageYPosition: 0)
            imageArray.append(image1)
            buttonView = addButton(buttonName: AssetsConstants.nextButton)
            buttonView.addTarget(self, action: #selector(updateControlPage), for: .touchUpInside)
            break
        case 2:
            goToDrawPage()
            break
        case 3:
            let label1 = addTextOnScreen(textContent: TextLevel1Constants.text4, textSize: 38, textYPosition: 0, numberOfLines: 1)
            let label2 = addTextOnScreen(textContent: TextLevel1Constants.text5, textSize: 48, textYPosition: 130, numberOfLines: 2)
            labelArray.append(contentsOf: [label1, label2])
            let image1 = addImageOnScreen(imageName: AssetsConstants.bobInitialLevel0, imageWidth: 130, imageHeight: 100, imageXPosition: 0, imageYPosition: 0)
            let image2 = addImageOnScreen(imageName: AssetsConstants.progress1, imageWidth: 545, imageHeight: 56, imageXPosition: 0, imageYPosition: 150)
            imageArray.append(contentsOf: [image1, image2])
            buttonView = addButton(buttonName: AssetsConstants.nextButton)
            buttonView.addTarget(self, action: #selector(updateControlPage), for: .touchUpInside)
            break
        case 4:
            let label1 = addTextOnScreen(textContent: TextLevel1Constants.text6, textSize: 28, textYPosition: 100, numberOfLines: 3)
            labelArray.append(contentsOf: [label1])
            let image1 = addImageOnScreen(imageName: AssetsConstants.bobTalkLevel0, imageWidth: 130, imageHeight: 100, imageXPosition: 0, imageYPosition: 0)
            imageArray.append(image1)
            buttonView = addButton(buttonName: AssetsConstants.nextButton)
            buttonView.addTarget(self, action: #selector(updateControlPage), for: .touchUpInside)
            break
        case 5:
            goToDrawPage()
            break
        case 6:
            let label1 = addTextOnScreen(textContent: TextLevel1Constants.text4, textSize: 38, textYPosition: 0, numberOfLines: 1)
            let label2 = addTextOnScreen(textContent: TextLevel1Constants.text7, textSize: 48, textYPosition: 130, numberOfLines: 1)
            labelArray.append(contentsOf: [label1, label2])
            let image1 = addImageOnScreen(imageName: AssetsConstants.bobInitialLevel0, imageWidth: 130, imageHeight: 100, imageXPosition: 0, imageYPosition: 0)
            let image2 = addImageOnScreen(imageName: AssetsConstants.progress2, imageWidth: 545, imageHeight: 56, imageXPosition: 0, imageYPosition: 150)
            imageArray.append(contentsOf: [image1, image2])
            buttonView = addButton(buttonName: AssetsConstants.nextButton)
            buttonView.addTarget(self, action: #selector(updateControlPage), for: .touchUpInside)
            break
        case 7:
            let label1 = addTextOnScreen(textContent: TextLevel1Constants.text8, textSize: 38, textYPosition: 0, numberOfLines: 1)
            let label2 = addTextOnScreen(textContent: TextLevel1Constants.text9, textSize: 28, textYPosition: 100, numberOfLines: 3)
            labelArray.append(contentsOf: [label1, label2])
            let image1 = addImageOnScreen(imageName: AssetsConstants.bobTalkLevel1, imageWidth: 130, imageHeight: 264, imageXPosition: 0, imageYPosition: 30)
            imageArray.append(image1)
            buttonView = addButton(buttonName: AssetsConstants.nextButton)
            buttonView.addTarget(self, action: #selector(updateControlPage), for: .touchUpInside)
            break
        default:
            changeToNextPage()
            break
        }
    }
    
    @objc func updateControlPage() {
        self.update += 1
        if isInExercice{
            backToLevel()
        }
        labelArray.forEach { label in
            label.removeFromSuperview()
        }
        labelArray.removeAll()
        imageArray.forEach { image in
            image.removeFromSuperview()
        }
        imageArray.removeAll()
        buttonView.removeFromSuperview()
        labelArray = [UILabel]()
        imageArray = [UIImageView]()
        buttonView = UIButton()
        updatePage(level: update)
    }
    
    func goToDrawPage() {
        view.addSubview(canvas)
        canvas.backgroundColor = .white
        canvas.frame = view.frame
        ExercicesConstants.listExercicesLevel1.forEach { (key: Int, value: String) in
            if key == nextListExercice {
                let image1 = addImageOnScreen(imageName: value, imageWidth: 280, imageHeight: 290, imageXPosition: 0, imageYPosition: -50)
                imageArray.append(image1)
                self.isInExercice = true
            }
        }
        buttonView = addButton(buttonName: AssetsConstants.finishedButton)
        buttonView.addTarget(self, action: #selector(updateControlPage), for: .touchUpInside)
    }
    
    func backToLevel() {
        imageArray.forEach { image in
            image.removeFromSuperview()
        }
        imageArray.removeAll()
        buttonView.removeFromSuperview()
        self.nextListExercice += 1
        self.isInExercice = false
        canvas.removeFromSuperview()
        canvas = Canvas()
        
    }
    
    func changeToNextPage() {
        let level = Level2()
        level.modalPresentationStyle = .fullScreen
        self.present(level, animated: false)
    }
}
